<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-27 03:53:42 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-27 03:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-27 04:10:28 --> Severity: error --> Exception: Call to undefined method Purchase_model::get_all_suppliers() C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Purchase.php 12
ERROR - 2018-04-27 04:10:30 --> Severity: error --> Exception: Call to undefined method Purchase_model::get_all_suppliers() C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Purchase.php 12
ERROR - 2018-04-27 04:11:26 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-27 04:11:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-27 04:12:02 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-27 04:12:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-27 04:13:01 --> Severity: Notice --> Undefined variable: suplr C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-27 04:13:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-27 04:13:40 --> Severity: Notice --> Undefined variable: suplr C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-27 04:13:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-27 04:18:15 --> Severity: Notice --> Undefined variable: suplr C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-27 04:18:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-27 04:42:59 --> Severity: Notice --> Use of undefined constant user - assumed 'user' C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_edit.php 38
ERROR - 2018-04-27 04:42:59 --> Severity: Warning --> Illegal string offset 'pur_date' C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_edit.php 38
ERROR - 2018-04-27 04:42:59 --> Severity: Notice --> Use of undefined constant user - assumed 'user' C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_edit.php 54
ERROR - 2018-04-27 04:42:59 --> Severity: Warning --> Illegal string offset 'pur_desc' C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_edit.php 54
ERROR - 2018-04-27 04:42:59 --> Severity: Notice --> Use of undefined constant user - assumed 'user' C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_edit.php 61
ERROR - 2018-04-27 04:42:59 --> Severity: Warning --> Illegal string offset 'pur_qty' C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_edit.php 61
ERROR - 2018-04-27 04:42:59 --> Severity: Notice --> Use of undefined constant user - assumed 'user' C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_edit.php 67
ERROR - 2018-04-27 04:42:59 --> Severity: Warning --> Illegal string offset 'pur_rate' C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_edit.php 67
ERROR - 2018-04-27 04:42:59 --> Severity: Notice --> Use of undefined constant user - assumed 'user' C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_edit.php 73
ERROR - 2018-04-27 04:42:59 --> Severity: Warning --> Illegal string offset 'pur_amount' C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_edit.php 73
ERROR - 2018-04-27 04:46:59 --> Query error: Unknown column 'pur_updateddate' in 'field list' - Invalid query: UPDATE `purchase` SET `pur_suplr_id` = '1', `pur_date` = '2018-04-23', `pur_godownid` = '1', `pur_desc` = '1', `pur_qty` = '1', `pur_rate` = '11', `pur_amount` = '8', `pur_updateddate` = '2018-04-27'
WHERE `pur_id` = '5'
ERROR - 2018-04-27 04:51:18 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:51:18 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:51:18 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:51:18 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:51:18 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:51:47 --> Severity: Notice --> Undefined index: supplier.suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:51:47 --> Severity: Notice --> Undefined index: supplier.suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:51:47 --> Severity: Notice --> Undefined index: supplier.suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:51:47 --> Severity: Notice --> Undefined index: supplier.suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:51:47 --> Severity: Notice --> Undefined index: supplier.suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:53:57 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:53:57 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:53:57 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:53:57 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:53:57 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:22 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:22 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:22 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:22 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:22 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:24 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:24 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:24 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:24 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:24 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:25 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:25 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:25 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:25 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:25 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:53 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:53 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:53 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:53 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:53 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:55 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:55 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:55 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:55 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:55 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:55 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:55 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:55 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:55 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:55 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:56 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:56 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:56 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:56 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:56 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:57 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:57 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:57 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:57 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:57 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:58 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:58 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:58 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:58 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 04:57:58 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_list.php 33
ERROR - 2018-04-27 05:21:31 --> Query error: Unknown column 'godown_id' in 'where clause' - Invalid query: DELETE FROM `bank`
WHERE `godown_id` = '1'
ERROR - 2018-04-27 05:24:53 --> Severity: Notice --> Undefined variable: gogown C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:24:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:24:55 --> Severity: Notice --> Undefined variable: gogown C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:24:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:24:56 --> Severity: Notice --> Undefined variable: gogown C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:24:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:24:56 --> Severity: Notice --> Undefined variable: gogown C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:24:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:25:39 --> Severity: Notice --> Undefined variable: gogown C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:25:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:25:40 --> Severity: Notice --> Undefined variable: gogown C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:25:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:25:41 --> Severity: Notice --> Undefined variable: gogown C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:25:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:26:07 --> Severity: Notice --> Undefined variable: gogown C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:26:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:26:13 --> Severity: Notice --> Undefined variable: gogown C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:26:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 48
ERROR - 2018-04-27 05:29:10 --> Query error: Unknown column 'purchase.godown.godown_name' in 'field list' - Invalid query: SELECT `purchase`.`pur_id`, `purchase`.`godown`.`godown_name`, `pur_date`, `supplier`.`suplr_name`, `purchase`.`pur_godownid`, `purchase`.`pur_desc`, `purchase`.`pur_qty`, `purchase`.`pur_rate`, `purchase`.`pur_amount`
FROM `purchase`
JOIN `supplier` ON `purchase`.`pur_suplr_id` = `supplier`.`suplr_id`
JOIN `godown` ON `purchase`.`pur_godownid` = `godown`.`godown_id`
ERROR - 2018-04-27 06:20:33 --> Query error: Unknown column 'sale.sale_suplr_id' in 'on clause' - Invalid query: SELECT `sale`.`sale_id`, `sale`.`sale_date`, `godown`.`godown_name`, `supplier`.`suplr_name`, `sale`.`sale_godownid`, `sale`.`sale_desc`, `sale`.`sale_qty`, `sale`.`sale_rate`, `sale`.`sale_amount`
FROM `sale`
JOIN `supplier` ON `sale`.`sale_suplr_id` = `supplier`.`suplr_id`
JOIN `godown` ON `sale`.`sale_godownid` = `godown`.`godown_id`
ERROR - 2018-04-27 07:14:54 --> Severity: error --> Exception: Call to undefined method Nsd_model::add_sale() C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Nsd.php 59
ERROR - 2018-04-27 07:16:04 --> Severity: error --> Exception: Call to undefined method Nsd_model::get_all_sale() C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Nsd.php 19
ERROR - 2018-04-27 07:19:14 --> Severity: error --> Exception: Call to undefined method Nsd_model::get_all_sale() C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Nsd.php 19
ERROR - 2018-04-27 07:20:59 --> Severity: error --> Exception: Call to undefined method Nsd_model::get_all_sale() C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Nsd.php 19
ERROR - 2018-04-27 07:21:19 --> Query error: Unknown column 'godown.godown_name' in 'field list' - Invalid query: SELECT `nsd`.`nsd_id`, `nsd`.`nsd_date`, `godown`.`godown_name`, `customer`.`cust_name`, `supplier`.`suplr_name`, `nsd`.`nsd_desc`, `nsd`.`nsd_qty`, `nsd`.`nsd_purrate`, `nsd`.`nsd_puramount`, `nsd`.`nsd_salerate`, `nsd`.`nsd_saleamount`
FROM `nsd`
JOIN `customer` ON `nsd`.`nsd_cust_id` = `customer`.`cust_id`
JOIN `supplier` ON `nsd`.`nsd_suplrid` = `supplier`.`suplr_id`
ERROR - 2018-04-27 07:21:41 --> Query error: Unknown column 'nsd.nsd_suplrid' in 'on clause' - Invalid query: SELECT `nsd`.`nsd_id`, `nsd`.`nsd_date`, `customer`.`cust_name`, `supplier`.`suplr_name`, `nsd`.`nsd_desc`, `nsd`.`nsd_qty`, `nsd`.`nsd_purrate`, `nsd`.`nsd_puramount`, `nsd`.`nsd_salerate`, `nsd`.`nsd_saleamount`
FROM `nsd`
JOIN `customer` ON `nsd`.`nsd_cust_id` = `customer`.`cust_id`
JOIN `supplier` ON `nsd`.`nsd_suplrid` = `supplier`.`suplr_id`
ERROR - 2018-04-27 07:25:06 --> Severity: Notice --> Undefined index: sale_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 20
ERROR - 2018-04-27 07:25:06 --> Severity: Notice --> Undefined index: sale_cust_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 29
ERROR - 2018-04-27 07:25:06 --> Severity: Notice --> Undefined index: sale_cust_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 29
ERROR - 2018-04-27 07:25:06 --> Severity: Notice --> Undefined index: sale_cust_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 29
ERROR - 2018-04-27 07:25:06 --> Severity: Notice --> Undefined index: sale_date C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 38
ERROR - 2018-04-27 07:25:17 --> Severity: Notice --> Undefined index: sale_cust_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 29
ERROR - 2018-04-27 07:25:17 --> Severity: Notice --> Undefined index: sale_cust_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 29
ERROR - 2018-04-27 07:25:17 --> Severity: Notice --> Undefined index: sale_cust_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 29
ERROR - 2018-04-27 07:25:17 --> Severity: Notice --> Undefined index: sale_date C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 38
ERROR - 2018-04-27 07:25:38 --> Severity: Notice --> Undefined index: sale_date C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 38
ERROR - 2018-04-27 07:28:01 --> Severity: Notice --> Undefined index: cust_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 29
ERROR - 2018-04-27 07:28:01 --> Severity: Notice --> Undefined index: sale_date C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 48
ERROR - 2018-04-27 07:28:21 --> Severity: Notice --> Undefined index: cust_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 29
ERROR - 2018-04-27 07:28:30 --> Severity: Notice --> Undefined index: cust_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 29
ERROR - 2018-04-27 07:30:47 --> Severity: Notice --> Undefined index: cust_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\nsd\nsd_edit.php 29
