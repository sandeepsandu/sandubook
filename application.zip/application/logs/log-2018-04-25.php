<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-25 13:21:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'db_username'@'localhost' (using password: YES) C:\wamp64\www\softwares\codeadmin\admincode\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-04-25 13:21:09 --> Unable to connect to the database
ERROR - 2018-04-25 13:21:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'db_username'@'localhost' (using password: YES) C:\wamp64\www\softwares\codeadmin\admincode\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-04-25 13:21:30 --> Unable to connect to the database
ERROR - 2018-04-25 13:21:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'db_username'@'localhost' (using password: YES) C:\wamp64\www\softwares\codeadmin\admincode\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-04-25 13:21:30 --> Unable to connect to the database
ERROR - 2018-04-25 13:21:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'db_username'@'localhost' (using password: YES) C:\wamp64\www\softwares\codeadmin\admincode\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-04-25 13:21:45 --> Unable to connect to the database
ERROR - 2018-04-25 13:21:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'db_username'@'localhost' (using password: YES) C:\wamp64\www\softwares\codeadmin\admincode\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-04-25 13:21:47 --> Unable to connect to the database
ERROR - 2018-04-25 13:21:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'db_username'@'localhost' (using password: YES) C:\wamp64\www\softwares\codeadmin\admincode\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-04-25 13:21:47 --> Unable to connect to the database
ERROR - 2018-04-25 15:38:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'db_username'@'localhost' (using password: YES) C:\wamp64\www\softwares\codeadmin\admincode\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-04-25 15:38:17 --> Unable to connect to the database
ERROR - 2018-04-25 17:24:04 --> Severity: Notice --> Undefined property: Customers::$user_model C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Customers.php 12
ERROR - 2018-04-25 17:24:04 --> Severity: error --> Exception: Call to a member function get_all_customers() on null C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Customers.php 12
ERROR - 2018-04-25 17:25:11 --> Severity: Notice --> Undefined variable: all_users C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:25:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:27:32 --> Severity: Notice --> Undefined variable: all_users C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:27:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:29:32 --> Severity: Notice --> Undefined variable: all_users C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:29:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:29:33 --> Severity: Notice --> Undefined variable: all_users C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:29:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:29:34 --> Severity: Notice --> Undefined variable: all_users C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:29:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:29:34 --> Severity: Notice --> Undefined variable: all_users C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:29:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:29:34 --> Severity: Notice --> Undefined variable: all_users C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:29:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_list.php 23
ERROR - 2018-04-25 17:31:32 --> Severity: Notice --> Undefined property: Customers::$user_model C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Customers.php 91
ERROR - 2018-04-25 17:31:32 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Customers.php 91
ERROR - 2018-04-25 17:34:01 --> Severity: Notice --> Undefined property: Customers::$user_model C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Customers.php 91
ERROR - 2018-04-25 17:34:01 --> Severity: error --> Exception: Call to a member function get_user_by_id() on null C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Customers.php 91
ERROR - 2018-04-25 17:35:02 --> Severity: Notice --> Undefined index: id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\users\user_edit.php 20
ERROR - 2018-04-25 17:35:02 --> Severity: Notice --> Undefined index: firstname C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\users\user_edit.php 25
ERROR - 2018-04-25 17:35:02 --> Severity: Notice --> Undefined index: lastname C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\users\user_edit.php 33
ERROR - 2018-04-25 17:35:02 --> Severity: Notice --> Undefined index: email C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\users\user_edit.php 41
ERROR - 2018-04-25 17:35:02 --> Severity: Notice --> Undefined index: mobile_no C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\users\user_edit.php 48
ERROR - 2018-04-25 17:35:02 --> Severity: Notice --> Undefined index: is_admin C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\users\user_edit.php 57
ERROR - 2018-04-25 17:35:02 --> Severity: Notice --> Undefined index: is_admin C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\users\user_edit.php 58
ERROR - 2018-04-25 17:36:15 --> Severity: Notice --> Undefined index: id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_edit.php 20
ERROR - 2018-04-25 17:36:17 --> Severity: Notice --> Undefined index: id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_edit.php 20
ERROR - 2018-04-25 17:37:23 --> 404 Page Not Found: admin/Customer/edit
ERROR - 2018-04-25 17:40:13 --> Query error: Unknown column 'username' in 'field list' - Invalid query: UPDATE `customer` SET `username` = 'Sandeep address111', `firstname` = 'Sandeep', `lastname` = 'address111', `email` = 'sanddep@yahoo.com', `mobile_no` = '9746464662', `password` = '$2y$10$BJdOqRp68h6Ib8DhEIbXSOW9zkgC3XdjC66WDPQHv8JeM.997TOPS', `is_admin` = '1', `updated_at` = '2018-04-25 : 05:04:13'
WHERE `cust_id` = '1'
ERROR - 2018-04-25 17:53:31 --> Severity: Notice --> Undefined property: Customers::$user_model C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Customers.php 44
ERROR - 2018-04-25 17:53:31 --> Severity: error --> Exception: Call to a member function add_user() on null C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Customers.php 44
ERROR - 2018-04-25 17:55:38 --> 404 Page Not Found: admin/Customer/del
ERROR - 2018-04-25 18:14:59 --> Severity: Notice --> Undefined variable: cust_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_edit.php 28
ERROR - 2018-04-25 18:14:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_edit.php 28
ERROR - 2018-04-25 18:15:18 --> Severity: Notice --> Undefined variable: cust_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_edit.php 28
ERROR - 2018-04-25 18:15:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\customer\customer_edit.php 28
ERROR - 2018-04-25 18:36:11 --> 404 Page Not Found: admin/Supplier/index
ERROR - 2018-04-25 18:36:53 --> Severity: error --> Exception: Call to undefined method Supplier_model::get_all_customers() C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Supplier.php 12
ERROR - 2018-04-25 18:38:33 --> Severity: Notice --> Undefined variable: all_customers C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_list.php 26
ERROR - 2018-04-25 18:38:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_list.php 26
ERROR - 2018-04-25 18:39:24 --> Query error: Table 'ci_adminlte_db.supplier_group' doesn't exist - Invalid query: SELECT *
FROM `supplier_group`
ERROR - 2018-04-25 18:42:05 --> Severity: Notice --> Undefined variable: cust_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_add.php 28
ERROR - 2018-04-25 18:42:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_add.php 28
ERROR - 2018-04-25 18:44:48 --> Severity: Notice --> Undefined index: cust_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_edit.php 20
ERROR - 2018-04-25 18:44:48 --> Severity: Notice --> Undefined variable: cust_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_edit.php 28
ERROR - 2018-04-25 18:44:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_edit.php 28
ERROR - 2018-04-25 18:44:48 --> Severity: Notice --> Undefined index: cust_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_edit.php 40
ERROR - 2018-04-25 18:44:48 --> Severity: Notice --> Undefined index: cust_address C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_edit.php 48
ERROR - 2018-04-25 18:44:48 --> Severity: Notice --> Undefined index: cust_email C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_edit.php 56
ERROR - 2018-04-25 18:44:48 --> Severity: Notice --> Undefined index: cust_mob C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_edit.php 63
ERROR - 2018-04-25 18:44:48 --> Severity: Notice --> Undefined index: cust_opencredit C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_edit.php 71
ERROR - 2018-04-25 18:44:48 --> Severity: Notice --> Undefined index: cust_opendebit C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_edit.php 79
ERROR - 2018-04-25 18:44:48 --> Severity: Notice --> Undefined index: cust_status C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_edit.php 88
ERROR - 2018-04-25 18:44:48 --> Severity: Notice --> Undefined index: cust_status C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\supplier\supplier_edit.php 89
ERROR - 2018-04-25 18:47:44 --> Severity: error --> Exception: Call to undefined method Supplier_model::edit_customer() C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Supplier.php 89
ERROR - 2018-04-25 19:15:25 --> Severity: error --> Exception: C:\wamp64\www\softwares\codeadmin\admincode\application\models/admin/Bank_model.php exists, but doesn't declare class Bank_model C:\wamp64\www\softwares\codeadmin\admincode\system\core\Loader.php 336
ERROR - 2018-04-25 19:15:53 --> Severity: Notice --> Undefined variable: all_suppliers C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_list.php 26
ERROR - 2018-04-25 19:15:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_list.php 26
ERROR - 2018-04-25 19:17:01 --> Severity: Notice --> Undefined variable: all_suppliers C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_list.php 26
ERROR - 2018-04-25 19:17:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_list.php 26
ERROR - 2018-04-25 19:19:08 --> Query error: Table 'ci_adminlte_db.bank_group' doesn't exist - Invalid query: SELECT *
FROM `bank_group`
ERROR - 2018-04-25 19:20:51 --> Severity: Notice --> Undefined variable: suplr_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_add.php 28
ERROR - 2018-04-25 19:20:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_add.php 28
ERROR - 2018-04-25 19:23:42 --> Severity: error --> Exception: Call to undefined method Bank_model::get_all_custgroups() C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Bank.php 63
ERROR - 2018-04-25 19:24:07 --> Severity: error --> Exception: Call to undefined method Bank_model::get_bank_by_id() C:\wamp64\www\softwares\codeadmin\admincode\application\controllers\admin\Bank.php 97
ERROR - 2018-04-25 19:24:31 --> Severity: Notice --> Undefined index: suplr_id C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_edit.php 20
ERROR - 2018-04-25 19:24:31 --> Severity: Notice --> Undefined variable: suplr_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_edit.php 28
ERROR - 2018-04-25 19:24:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_edit.php 28
ERROR - 2018-04-25 19:24:31 --> Severity: Notice --> Undefined index: suplr_name C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_edit.php 40
ERROR - 2018-04-25 19:24:31 --> Severity: Notice --> Undefined index: suplr_address C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_edit.php 48
ERROR - 2018-04-25 19:24:31 --> Severity: Notice --> Undefined index: suplr_email C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_edit.php 56
ERROR - 2018-04-25 19:24:31 --> Severity: Notice --> Undefined index: suplr_mob C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_edit.php 63
ERROR - 2018-04-25 19:24:31 --> Severity: Notice --> Undefined index: suplr_opencredit C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_edit.php 71
ERROR - 2018-04-25 19:24:31 --> Severity: Notice --> Undefined index: suplr_opendebit C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_edit.php 79
ERROR - 2018-04-25 19:24:31 --> Severity: Notice --> Undefined index: suplr_status C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_edit.php 88
ERROR - 2018-04-25 19:24:31 --> Severity: Notice --> Undefined index: suplr_status C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\bank\bank_edit.php 89
