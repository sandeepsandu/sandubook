<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-26 05:20:23 --> 404 Page Not Found: admin/Auth/home
ERROR - 2018-04-26 05:20:27 --> 404 Page Not Found: admin/Home/index
ERROR - 2018-04-26 10:11:48 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:11:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:12:30 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:12:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:13:03 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:13:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:13:21 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:13:22 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:13:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:14:06 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:14:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:14:32 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:14:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:14:33 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:15:45 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:15:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:16:28 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:16:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:16:44 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:16:45 --> Severity: Notice --> Undefined variable: bank_group C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
ERROR - 2018-04-26 10:16:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\softwares\codeadmin\admincode\application\views\admin\purchase\purchase_add.php 28
