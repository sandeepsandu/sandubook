<?php
	class Purchase_model extends CI_Model{

		public function add_purchase($data){
			$this->db->insert('purchase', $data);
			return true;
		}

		public function get_all_purchase(){
            $this->db->select('purchase.pur_id,purchase.pur_date,godown.godown_name,supplier.suplr_name,purchase.pur_godownid,purchase.pur_desc,purchase.pur_qty,purchase.pur_rate,purchase.pur_amount');
            $this->db->from('purchase');
            $this->db->join('supplier', 'purchase.pur_suplr_id = supplier.suplr_id');
            $this->db->join('godown', 'purchase.pur_godownid = godown.godown_id');
            $query = $this->db->get();
			return $result = $query->result_array();
		}

		public function get_purchase_by_id($id){
			$query = $this->db->get_where('purchase', array('pur_id' => $id));
			return $result = $query->row_array();
		}

		public function edit_purchase($data, $id){
			$this->db->where('pur_id', $id);
			$this->db->update('purchase', $data);
			return true;
		}

        public function get_all_suppliers(){
            $query = $this->db->get('supplier');
            return $result = $query->result_array();
        }

        public function get_all_godowns(){
            $query = $this->db->get('godown');
            return $result = $query->result_array();
        }

	}

?>