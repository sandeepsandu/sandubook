<?php
	class Customer_model extends CI_Model{

		public function add_user($data){
			$this->db->insert('customer', $data);
			return true;
		}

		public function get_all_customers(){
			$query = $this->db->get('customer');
			return $result = $query->result_array();
		}

		public function get_user_by_id($id){
			$query = $this->db->get_where('customer', array('cust_id' => $id));
			return $result = $query->row_array();
		}

		public function edit_customer($data, $id){
			$this->db->where('cust_id', $id);
			$this->db->update('customer', $data);
			return true;
		}

        public function get_all_custgroups(){
            $query = $this->db->get('customer_group');
            return $result = $query->result_array();
        }

	}

?>